
#ifndef BOOST_MPL_AUX_HAS_TYPE_HPP_INCLUDED
#define BOOST_MPL_AUX_HAS_TYPE_HPP_INCLUDED

// Copyright Aleksey Gurtovoy 2002-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Source: /cvsroot/smartwin/SmartWin/include/boost/mpl/aux_/has_type.hpp,v $
// $Date: 2006/03/24 17:29:17 $
// $Revision: 1.3 $

#include <boost/mpl/has_xxx.hpp>

namespace boost { namespace mpl { namespace aux {
BOOST_MPL_HAS_XXX_TRAIT_NAMED_DEF(has_type, type, true)
}}}

#endif // BOOST_MPL_AUX_HAS_TYPE_HPP_INCLUDED
