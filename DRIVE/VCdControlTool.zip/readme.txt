Readme for Virtual CD-ROM Control Panel v2.0.1.1

THIS TOOL IS UNSUPPORT BY MICROSOFT PRODUCT SUPPORT SERVICES


System Requirements
===================
- Windows XP Home or Windows XP Professional

Installation instructions
=========================
1. Copy VCdRom.sys to your %systemroot%\system32\drivers folder. 
2. Execute VCdControlTool.exe
3. Click "Driver control"
4. If the "Install Driver" button is available, click it. Navigate to the %systemroot%\system32\drivers folder, select VCdRom.sys, and click Open.
5. Click "Start"
6. Click OK
7. Click "Add Drive" to add a drive to the drive list. Ensure that the drive added is not a local drive. If it is, continue to click "Add Drive" until an unused drive letter is available.
8. Select an unused drive letter from the drive list and click "Mount".
9. Navigate to the image file, select it, and click "OK". UNC naming conventions should not be used, however mapped network drives should be OK.

You may now use the drive letter as if it were a local CD-ROM device. When you are finished you may unmount, stop, and remove the driver from memory using the driver control.
